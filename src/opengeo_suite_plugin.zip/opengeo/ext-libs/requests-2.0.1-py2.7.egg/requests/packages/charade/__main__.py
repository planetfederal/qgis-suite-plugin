'''
support ';python -m charade <file1> [file2] ...' package execution syntax (2.7+)
'''

from charade import charade_cli

charade_cli()
